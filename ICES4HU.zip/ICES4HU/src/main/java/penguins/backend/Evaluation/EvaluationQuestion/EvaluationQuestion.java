package penguins.backend.Evaluation.EvaluationQuestion;

import lombok.Data;

@Data
public class EvaluationQuestion {
    private long id;
    private String questionText;
}
