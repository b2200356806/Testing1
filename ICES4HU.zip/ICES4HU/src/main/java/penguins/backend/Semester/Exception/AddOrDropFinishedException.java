package penguins.backend.Semester.SemesterException;

public class AddOrDropFinishedException extends RuntimeException {
    public AddOrDropFinishedException(String message) {
        super(message);
    }
}
